SHAMMAH EXCEL CENTRE — ANDROID APK BUILD

This project builds a standalone Android WebView application. The HTML app is packaged inside app/src/main/assets/index.html and loads from local app storage; it does not need Chrome or an internet connection to launch.

PHONE-ONLY BUILD USING GITHUB ACTIONS
1. Extract this ZIP on your Android phone.
2. Open your existing GitHub repository (shammah-excel-centre1 or your repository).
3. Upload the contents of this folder into the repository root. IMPORTANT: upload the .github folder too. The app folder, build.gradle, settings.gradle and gradle.properties must be at repository root.
4. Commit the uploaded files.
5. In the repository, open Actions. If prompted, enable GitHub Actions.
6. Select “Build SHAMMAH EXCEL CENTRE APK” and tap “Run workflow”. If it runs automatically after your commit, you can skip this step.
7. Wait for the workflow to finish with a green check.
8. Open the completed workflow run, scroll to Artifacts, and download SHAMMAH-EXCEL-CENTRE-debug-apk.
9. Extract the downloaded artifact ZIP and install app-debug.apk. Android may ask you to allow installs from that browser/files app; only allow it for this APK you built from your own repository.

The APK is a debug build for direct installation/testing, not a Play Store release. Data is stored locally on the device. Export backups regularly. Cloud sync and email-based password reset are not implemented. The simple local login is a device-only gate, not secure multi-user authentication. Check fee settings and balances before using it for official accounts; the balance calculation is a basic total-fees-minus-payments estimate and does not yet implement term-by-term carry-forward accounting.
